# 🎵 AURA Bot — Инструкция по деплою

## Что умеет бот

| Команда | Описание |
|---------|----------|
| `/status` | Статус плеера, кол-во треков, прослушивания |
| `/tracks` | Список всех треков с ID и длительностью |
| `/download <url>` | Скачать трек с **YouTube / SoundCloud** и загрузить в базу |
| `/block` | Заблокировать плеер (пользователи видят экран блокировки) |
| `/unblock` | Разблокировать плеер |
| `/delete <id>` | Удалить трек по ID (удаляет файлы из Storage) |

Плюс **автоуведомления**: при добавлении нового трека через плеер или админку — бот сразу пришлёт сообщение.

---

## Шаг 1 — Создать бота в Telegram

1. Открой [@BotFather](https://t.me/BotFather)
2. Напиши `/newbot`
3. Придумай имя (например: `AURA Music`) и username (например: `aura_music_bot`)
4. Скопируй **токен** вида `1234567890:AAxxx...`

---

## Шаг 2 — Узнать свой chat_id

1. Напиши [@userinfobot](https://t.me/userinfobot) или [@getmyid_bot](https://t.me/getmyid_bot)
2. Скопируй число — это твой `ADMIN_CHAT_ID`

---

## Шаг 3 — Настройка Supabase

1. Открой [Supabase](https://supabase.com) → твой проект
2. Перейди в **SQL Editor → New query**
3. Вставь содержимое файла `supabase_setup.sql` и нажми **Run ▶**
   - Создастся таблица `settings` (для хранения флага блокировки)
   - Создастся триггер для уведомлений (URL заполнишь после деплоя)

---

## Шаг 4 — Деплой на Railway (бесплатно)

### 4.1 Создай GitHub репозиторий

```bash
cd aura-bot
git init
git add .
git commit -m "AURA Bot initial"
# Создай репо на github.com и запушь
git remote add origin https://github.com/твой-юзер/aura-bot.git
git push -u origin main
```

### 4.2 Создай проект на Railway

1. Зайди на [railway.app](https://railway.app)
2. **New Project → Deploy from GitHub repo** → выбери `aura-bot`
3. Railway сам обнаружит `Dockerfile` и соберёт образ

### 4.3 Добавь переменные окружения

В Railway → твой проект → **Variables** → добавь:

```
BOT_TOKEN        = токен от BotFather
ADMIN_CHAT_ID    = твой chat_id (число)
WEBHOOK_SECRET   = aura_secret_2024  (или придумай своё)
PUBLIC_URL       = (оставь пустым, заполнишь через минуту)
```

Остальные (SB_URL, SB_KEY, SB_BUCKET) уже вшиты в код, но можешь переопределить.

### 4.4 Получи публичный URL

В Railway → **Settings → Networking → Generate Domain**  
Получишь URL типа: `https://aura-bot-production.up.railway.app`

### 4.5 Добавь PUBLIC_URL

В Variables добавь:
```
PUBLIC_URL = https://aura-bot-production.up.railway.app
```
Нажми **Redeploy**.

### 4.6 Обнови Supabase триггер

В `supabase_setup.sql` замени URL в функции `notify_track_added` на реальный и перезапусти SQL.

---

## Шаг 5 — Проверка

1. Напиши боту `/start` — должно прийти меню
2. Напиши `/status` — должна прийти статистика
3. Напиши `/download https://soundcloud.com/любой-трек` — трек должен появиться в плеере
4. Добавь трек через веб-плеер или админку — бот должен прислать уведомление

---

## Альтернатива: Render.com

Если Railway не подходит, используй [Render](https://render.com):
1. New → Web Service → GitHub repo
2. Runtime: **Docker**
3. Добавь те же переменные окружения
4. После деплоя скопируй URL вида `https://aura-bot.onrender.com`

> ⚠️ На бесплатном Render сервис засыпает после 15 мин бездействия.  
> Railway не засыпает (500 часов/месяц бесплатно).

---

## Локальный запуск (для теста)

```bash
# Установи зависимости
pip install -r requirements.txt

# Для скачивания треков нужен ffmpeg:
# macOS:  brew install ffmpeg
# Ubuntu: sudo apt install ffmpeg
# Windows: скачай с ffmpeg.org

# Создай .env файл из .env.example и заполни
cp .env.example .env
# Открой .env и заполни BOT_TOKEN, ADMIN_CHAT_ID

# Запусти
python bot.py
```

При локальном запуске webhook не работает (нет публичного URL).  
Для теста команд это не нужно — команды работают через polling тоже,  
но для этого надо добавить polling-режим (или использовать ngrok).

---

## Структура файлов

```
aura-bot/
├── bot.py              # Основной код бота
├── requirements.txt    # Зависимости Python
├── Dockerfile          # Для Railway/Render
├── .env.example        # Пример переменных окружения
├── supabase_setup.sql  # SQL для Supabase
└── README.md           # Эта инструкция
```
